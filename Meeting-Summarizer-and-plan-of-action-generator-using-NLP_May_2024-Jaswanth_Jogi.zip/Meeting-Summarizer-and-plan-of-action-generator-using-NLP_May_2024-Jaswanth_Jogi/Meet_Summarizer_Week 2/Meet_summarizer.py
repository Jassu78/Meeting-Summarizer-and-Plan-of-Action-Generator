import whisper
import subprocess
import os
import boto3
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lsa import LsaSummarizer
import warnings
from whisper import load_model

# Suppress specific warning
warnings.filterwarnings("ignore", message="FP16 is not supported on CPU; using FP32 instead")

def download_file_from_s3(bucket_name, object_name, local_file_path, aws_access_key_id, aws_secret_access_key, region_name):
    """Download a file from S3 bucket to local filesystem."""
    # Create an S3 client
    s3 = boto3.client('s3',
                      aws_access_key_id=aws_access_key_id,
                      aws_secret_access_key=aws_secret_access_key,
                      region_name=region_name)

    try:
        # Download file from S3 bucket
        s3.download_file(bucket_name, object_name, local_file_path)
        print(f"File downloaded from S3 bucket {bucket_name} with key {object_name} to {local_file_path}")
        return True
    except Exception as e:
        print(f"Error downloading file from S3 bucket: {e}")
        return False

def convert_video_to_text_and_summarize_from_s3(bucket_name, object_name, output_text_file_path, output_summary_file_path, aws_access_key_id, aws_secret_access_key, region_name):
    """Converts a video file from S3 to text and generates a summary using extractive summarization.

    Args:
        bucket_name: Name of the S3 bucket.
        object_name: Key (path) of the video file in the S3 bucket.
        output_text_file_path: Path to save the extracted text.
        output_summary_file_path: Path to save the summary.
        aws_access_key_id: AWS Access Key ID.
        aws_secret_access_key: AWS Secret Access Key.
        region_name: AWS region where the S3 bucket resides.
    """

    # Download video file from S3 bucket
    downloaded_video_path = "downloaded_video.mp4"  # Local path to store downloaded file
    download_file_from_s3(bucket_name, object_name, downloaded_video_path, aws_access_key_id, aws_secret_access_key, region_name)

    # Extract audio from downloaded video using Ffmpeg
    temporary_audio_file = "temp_audio.mp3"
    subprocess.run(["ffmpeg", "-i", downloaded_video_path, "-vn", temporary_audio_file])

    # Transcribe audio to text using Whisper
    model = whisper.load_model("base")  # You can adjust the model size here
    result = model.transcribe(temporary_audio_file)
    text = result["text"]

    # Write text to output file
    with open(output_text_file_path, "w", encoding="utf-8") as f:
        f.write(text)

    # Delete temporary audio file using os.remove for portability
    os.remove(temporary_audio_file)
    # Delete downloaded video file
    os.remove(downloaded_video_path)

    # Summarize the extracted text
    parser = PlaintextParser.from_file(output_text_file_path, Tokenizer("english"))
    summarizer = LsaSummarizer()
    summary = summarizer(parser.document, 2)  # Number of sentences in the summary

    # Write summary to output file
    with open(output_summary_file_path, "w", encoding="utf-8") as f:
        for sentence in summary:
            f.write(str(sentence) + "\n")

# Example usage
bucket_name = 'meeting-summarizer-internship'  # Name of your S3 bucket
object_name = 'story.mp4'  # S3 object key (path to video file in bucket)
output_text_file_path = "output.txt"  # Output path for extracted text
output_summary_file_path = "summary.txt"  # Output path for summary
aws_access_key_id = 'AKIAYAV34GOXGLQT2OVM'  # Your AWS Access Key ID
aws_secret_access_key = 'Mq3cEsJMCnqfYZSe63zdXl8wca9Dzl1hUqvM9ZSW'  # Your AWS Secret Access Key
region_name = 'ap-south-1'  # AWS region where the S3 bucket resides

convert_video_to_text_and_summarize_from_s3(bucket_name, object_name, output_text_file_path, output_summary_file_path, aws_access_key_id, aws_secret_access_key, region_name)
