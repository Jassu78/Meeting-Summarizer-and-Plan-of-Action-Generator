# Meeting-Summarizer-and-plan-of-action-generator-using-NLP

This Streamlit-based application automates the process of summarizing meeting videos stored on OneDrive. The application downloads the video, extracts the audio, transcribes it, and generates a summary along with a plan of action. The summary and plan are then sent to specified email addresses.

## Features

- **Authentication**: Uses Microsoft Azure's MSAL library to handle authentication and obtain an access token.
- **Video Download**: Lists and downloads meeting videos from a specified OneDrive folder.
- **Audio Extraction**: Extracts audio from the downloaded video using FFmpeg.
- **Transcription**: Transcribes the extracted audio using the Whisper library.
- **Summarization**: Generates a summary and a plan of action for the meeting using OpenAI's GPT-3.5-turbo model.
- **Email Sending**: Sends the generated summary and plan to specified email addresses using SMTP.


## Usage

1. **Authenticate**: The application will use the provided credentials to authenticate and obtain an access token.

2. **Select a Video**: The application will list the available meeting videos in the specified OneDrive folder. Select a video from the dropdown menu.

3. **Enter Email Addresses**: Enter the email addresses of the recipients, separated by commas.

4. **Process Video**: Click the "Process Video" button to start the processing. The application will:
    - Download the video from OneDrive.
    - Extract the audio from the video.
    - Transcribe the audio.
    - Generate a summary and a plan of action.
    - Send the summary and plan via email to the specified recipients.

## Dependencies

- **Streamlit**: For building the web application interface.
- **MSAL**: For authentication with Microsoft Azure.
- **Requests**: For making HTTP requests to the Microsoft Graph API.
- **OpenAI**: For generating summaries and plans using GPT-3.5-turbo.
- **Subprocess**: For running FFmpeg commands to extract audio.
- **Whisper**: For transcribing audio to text.
- **SMTP**: For sending emails with the generated summaries and plans.

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## Acknowledgements

- [Streamlit](https://www.streamlit.io/)
- [MSAL](https://github.com/AzureAD/microsoft-authentication-library-for-python)
- [OpenAI](https://www.openai.com/)
- [FFmpeg](https://www.ffmpeg.org/)
- [Whisper](https://github.com/openai/whisper)

## Author

- Jaswanth Jogi
