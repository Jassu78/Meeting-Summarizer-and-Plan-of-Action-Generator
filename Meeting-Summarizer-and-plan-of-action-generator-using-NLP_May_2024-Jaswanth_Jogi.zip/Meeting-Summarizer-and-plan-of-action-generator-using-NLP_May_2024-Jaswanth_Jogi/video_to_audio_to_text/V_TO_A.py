import subprocess

def convert_video_to_audio(video_file_path, output_file_path):
  """Converts a video file to an audio file using Ffmpeg.

  Args:
    video_file_path: Path to the input video file.
    output_file_path: Path to the output audio file.
  """

  command = ["ffmpeg", "-i", video_file_path, "-vn", output_file_path]
  subprocess.run(command)

# Example usage
video_file_path = "story.mp4"
output_file_path = "t1.mp3"
convert_video_to_audio(video_file_path, output_file_path)

