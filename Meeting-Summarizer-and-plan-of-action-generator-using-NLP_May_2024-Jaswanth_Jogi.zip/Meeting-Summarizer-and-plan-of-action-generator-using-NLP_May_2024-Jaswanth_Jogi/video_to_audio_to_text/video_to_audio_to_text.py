import whisper
import subprocess
import os

def convert_video_to_text(video_file_path, output_text_file_path):
  """Converts a video file to text using Ffmpeg and Whisper.

  Args:
    video_file_path: Path to the input video file.
    output_text_file_path: Path to the output text file.
  """

  # Extract audio from video using Ffmpeg
  temporary_audio_file = "temp_audio.mp3"
  subprocess.run(["ffmpeg", "-i", video_file_path, "-vn", temporary_audio_file])

  # Transcribe audio to text using Whisper
  model = whisper.load_model("base")  # You can adjust the model size here
  result = model.transcribe(temporary_audio_file)
  text = result["text"]

  # Write text to output file
  with open(output_text_file_path, "w", encoding="utf-8") as f:
    f.write(text)

  # Delete temporary audio file using os.remove for portability
  os.remove(temporary_audio_file)

# Example usage
video_file_path = "story.mp4"
output_text_file_path = "output.txt"
convert_video_to_text(video_file_path, output_text_file_path)
