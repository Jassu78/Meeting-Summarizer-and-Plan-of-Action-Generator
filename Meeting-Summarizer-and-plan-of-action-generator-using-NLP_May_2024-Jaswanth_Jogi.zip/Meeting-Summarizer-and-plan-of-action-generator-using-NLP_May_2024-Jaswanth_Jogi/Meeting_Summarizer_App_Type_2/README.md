# **Meeting Summarizer Type 2 ( Two Functionalities Model )**
# Project Workflow:
    Starts with the main Interface showing 2 options to Proceed with.
    1. Start Meeting
    2. Proceed with the existing Meeting record.
  Both have their own separate Functionalities.
  
**1st Option Workflow:**

   * Takes **Meeting Link & Emails** as Input.
   * Automatically joins the meeting. 
   * Ask the user to Click on the "Record & Transcribe " option.
   * From there on, Code waits for the meeting to appear on Onedrive Folder (Recordings). 
   * and Processes the Meeting Without user interference.
     
**NOTE :** *The Process is fully Automated , the user needs to start recording only, Recording will automatically Stored in Onedrive Folder.*

**2nd Option Workflow:**

* It helps the user to Process the Previous Meetings on his Wish.
* Lists out all Recordings from onedrive. (shortened based on date and time)
* After selecting Video and taking mails, It processes the Video and Sends Mails.
* Users can use this functionality to directly process meetings even after meeting.
