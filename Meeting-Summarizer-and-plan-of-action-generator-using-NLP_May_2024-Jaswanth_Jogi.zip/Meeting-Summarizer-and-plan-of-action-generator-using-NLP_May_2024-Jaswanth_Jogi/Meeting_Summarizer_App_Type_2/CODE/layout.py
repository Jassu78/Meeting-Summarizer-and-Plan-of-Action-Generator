import streamlit as st
import os

st.title("Meet_Summarizer (Choose Option)")

option = st.selectbox("Select an option", ["", "Start Meeting", "Proceed with Existing Recording"])

if option == "Start Meeting":
    st.write("You chose Option 1")
    os.system("streamlit run option1.py")
elif option == "Proceed with Existing Recording":
    st.write("You chose Option 2")
    os.system("streamlit run option2.py")
