import streamlit as st

# Option 2: run the start.py script
exec(open("existing.py").read())
