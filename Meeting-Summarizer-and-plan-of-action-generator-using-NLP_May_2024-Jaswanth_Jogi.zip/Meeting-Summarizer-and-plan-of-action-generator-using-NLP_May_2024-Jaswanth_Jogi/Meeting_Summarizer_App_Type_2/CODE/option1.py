import streamlit as st
import msal
import requests
import os
import openai
import subprocess
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from whisper import load_model
import smtplib
from datetime import datetime, timezone
import webbrowser
import time

# Configuration
client_id = '8ae88068-e20c-45fb-8604-3b91437ab88d'
client_secret = '-O38Q~SbKXfVwG_2ebHkX79vhnELeHdm-y7GbaIM'
tenant_id = '8fad9761-fadb-41b6-8a1d-dc05d5dc4f9b'
site_id = 'fcd5aa63-3a26-4270-910c-d4967f14132f'
drive_id = 'b!Y6rV_CY6cEKRDNSWfxQTLyS310PcuMBOskjGyan4ngeh8vQaKcfYRJmJ9FLuoMKQ'
openai_api_key = 'sk-proj-2B9XaHHDeIAdXj0kj71iT3BlbkFJWq3QDjgQVNbHyjPmdlXH'
sender_email = 'YOUR MAIL ID'
email_password = 'PASSWORD'

def get_access_token(client_id, client_secret, tenant_id):
    authority = f"https://login.microsoftonline.com/{tenant_id}"
    scopes = ["https://graph.microsoft.com/.default"]

    app = msal.ConfidentialClientApplication(
        client_id,
        authority=authority,
        client_credential=client_secret,
    )

    result = app.acquire_token_for_client(scopes)
    if "access_token" in result:
        return result['access_token']
    else:
        st.error("Error acquiring token.")
        st.stop()

def list_items_in_folder(site_id, drive_id, access_token):
    list_items_endpoint = f'https://graph.microsoft.com/v1.0/sites/{site_id}/drives/{drive_id}/root:/Recordings:/children'
    headers = {'Authorization': 'Bearer ' + access_token}
    response = requests.get(list_items_endpoint, headers=headers)
    if response.status_code == 200:
        items = response.json()['value']
        items_with_dates = [
            (item['name'], item['id'], item['fileSystemInfo']['createdDateTime'])
            for item in items
        ]
        sorted_items = sorted(items_with_dates, key=lambda x: x[2], reverse=True)
        return sorted_items
    else:
        st.error("Error listing items.")
        st.stop()

def download_from_onedrive(site_id, drive_id, item_id, access_token, local_file_path):
    download_endpoint = f'https://graph.microsoft.com/v1.0/sites/{site_id}/drives/{drive_id}/items/{item_id}/content'
    headers = {'Authorization': 'Bearer ' + access_token}
    response = requests.get(download_endpoint, headers=headers)
    if response.status_code == 200:
        with open(local_file_path, 'wb') as file:
            file.write(response.content)
        return True
    else:
        st.error(f"Error downloading file from OneDrive: {response.status_code}, {response.json()}")
        return False

def summarize_and_generate_plan(text, openai_api_key):
    openai.api_key = openai_api_key
    prompt = (
        "Generate the topic of the meeting, meeting type, category of meeting, and related field. "
        "Also, summarize the following meeting transcript and generate a plan of action with a maximum of 5 points:\n\n"
        f"{text}\n\n"
        "Topic of Meeting:\n"
        "Meeting Type:\n"
        "Category of Meeting:\n"
        "Related Field:\n"
        "Summary:\n\n"
        "Plan of Action (5 points):\n"
    )
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=500,
        temperature=0.7
    )
    summary_and_plan = response.choices[0].message["content"].strip()
    return summary_and_plan

def send_email(summary_and_plan, sender_email, receiver_emails, email_password):
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = ", ".join(receiver_emails)
    msg['Subject'] = "Meeting Summary and Plan of Action"

    email_body = """
    <p><strong>Greetings,</strong></p>
    <p>{summary_and_plan}</p>
    <p>Thanks for attending the session.</p>
    <p> Best Regards,</p>
    <p>Jaswanth Jogi.</p>
    """.format(summary_and_plan=summary_and_plan.replace('\n', '<br>'))

    msg.attach(MIMEText(email_body, 'html'))

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, email_password)
        server.sendmail(sender_email, receiver_emails, msg.as_string())
        server.quit()
    except Exception as e:
        st.error(f"Error sending email: {e}")

def process_video(item_id, site_id, drive_id, access_token, openai_api_key, sender_email, receiver_emails, email_password):
    with st.spinner("Downloading video from OneDrive..."):
        local_file_path = "downloaded_video.mp4"
        if download_from_onedrive(site_id, drive_id, item_id, access_token, local_file_path):
            st.success("Video downloaded successfully.")
        else:
            st.error("Failed to download video.")
            return

    with st.spinner("Extracting audio from video..."):
        temporary_audio_file = "temp_audio.mp3"
        subprocess.run(["ffmpeg", "-i", local_file_path, "-vn", temporary_audio_file])
        st.success("Audio extracted successfully.")

    with st.spinner("Transcribing audio..."):
        model = load_model("base")
        result = model.transcribe(temporary_audio_file)
        text = result["text"]
        st.success("Audio transcribed successfully.")
        os.remove(temporary_audio_file)

    os.remove(local_file_path)

    with st.spinner("Generating summary and plan of action..."):
        summary_and_plan = summarize_and_generate_plan(text, openai_api_key)
        st.success("Summary and plan generated successfully.")

    with st.spinner("Sending email..."):
        send_email(summary_and_plan, sender_email, receiver_emails, email_password)
        st.success("Email sent successfully!")

def main():
    st.title("Microsoft Teams Meeting Summarizer")

    meeting_link = st.text_input("Enter Microsoft Teams Meeting Link", key="meeting_link")
    emails = st.text_area("Enter Recipient Email Addresses (comma-separated)", key="emails")

    if st.button("Start Recording", key="start_button"):
        if not meeting_link:
            st.error("Please enter a Microsoft Teams meeting link.")
        elif not emails:
            st.error("Please enter at least one recipient email address.")
        else:
            receiver_emails = [email.strip() for email in emails.split(",")]
            access_token = get_access_token(client_id, client_secret, tenant_id)
            items = list_items_in_folder(site_id, drive_id, access_token)
            initial_item_ids = {item[1] for item in items}
            st.info("Kindly, After Joining the Meeting Initiate the meeting recording.")
            # Wait for 5 seconds and open the meeting link in a new tab
            with st.spinner("Opening meeting link in 5 seconds..."):
                time.sleep(5)
            webbrowser.open_new_tab(meeting_link)

            # Wait for a new video to appear
            st.info("Waiting for new video to appear in OneDrive...")
            new_item_id = None
            while not new_item_id:
                time.sleep(10)  # Check every 10 seconds
                items = list_items_in_folder(site_id, drive_id, access_token)
                current_item_ids = {item[1] for item in items}
                new_items = current_item_ids - initial_item_ids
                if new_items:
                    new_item_id = new_items.pop()

            process_video(new_item_id, site_id, drive_id, access_token, openai_api_key, sender_email, receiver_emails, email_password)

if __name__ == "__main__":
    main()
