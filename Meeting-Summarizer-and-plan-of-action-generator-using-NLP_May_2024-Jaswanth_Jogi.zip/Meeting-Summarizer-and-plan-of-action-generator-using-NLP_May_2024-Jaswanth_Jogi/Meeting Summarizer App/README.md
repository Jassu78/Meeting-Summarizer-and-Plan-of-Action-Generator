# Meeting Summarizer and Plan of Action Generator Application

This Streamlit-based application automates the process of summarizing meeting videos stored on OneDrive. The application downloads the video, extracts the audio, transcribes it, and generates a summary along with a plan of action. The summary and plan are then sent to specified email addresses.

## How the App Works

1. **User Authentication**:
    - The application uses Microsoft Azure's MSAL library to handle authentication.
    - It obtains an access token using the provided client ID, client secret, and tenant ID.

2. **Listing Meeting Videos**:
    - The application lists available meeting videos from a specified OneDrive folder.
    - It uses the Microsoft Graph API to access the OneDrive folder and retrieve the list of video files.

3. **Downloading the Selected Video**:
    - The user selects a video from the listed options.
    - The application downloads the selected video from OneDrive to a local file.

4. **Extracting Audio from the Video**:
    - The application uses FFmpeg to extract audio from the downloaded video.
    - The extracted audio is saved as a temporary file.

5. **Transcribing Audio to Text**:
    - The application uses the Whisper library to transcribe the extracted audio.
    - The transcription process converts the audio content into text.

6. **Generating a Summary and Plan of Action**:
    - The application uses OpenAI's GPT-3.5-turbo model to generate a summary and a plan of action based on the transcribed text.
    - The generated content includes the topic of the meeting, meeting type, category, related field, and a concise summary with actionable points.

7. **Sending the Summary and Plan via Email**:
    - The application composes an email with the generated summary and plan.
    - It uses SMTP to send the email to the specified recipients.

## Usage

1. **Run the Application**:
    - Start the application using Streamlit.
    - The application will open in your default web browser.

2. **Authenticate**:
    - The application will authenticate with Microsoft Azure using the provided credentials.

3. **Select a Video**:
    - Choose a video from the list of available meeting videos in the OneDrive folder.

4. **Enter Email Addresses**:
    - Provide the email addresses of the recipients, separated by commas.

5. **Process the Video**:
    - Click the "Process Video" button.
    - The application will perform all the steps to download, extract, transcribe, generate a summary, and send the email.

6. **Receive the Email**:
    - The specified recipients will receive an email with the meeting summary and plan of action.

## Author

- Jaswanth Jogi
