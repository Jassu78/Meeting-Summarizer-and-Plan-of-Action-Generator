import os
import boto3
import openai
import smtplib
import subprocess
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from whisper import load_model

def download_file_from_s3(bucket_name, object_name, local_file_path, access_key_id, secret_access_key, region_name):
    """Download a file from S3 bucket."""
    s3 = boto3.client('s3',
                      aws_access_key_id=access_key_id,
                      aws_secret_access_key=secret_access_key,
                      region_name=region_name)
    try:
        s3.download_file(bucket_name, object_name, local_file_path)
        print(f"Downloaded video from S3: {object_name}")
        return True
    except Exception as e:
        print(f"Error downloading file: {e}")
        return False

def summarize_and_generate_plan(text, openai_api_key):
    """Summarizes text and generates a plan of action using OpenAI."""
    openai.api_key = openai_api_key
    prompt = (
        "Summarize the following meeting transcript and generate a plan of action with a maximum of 5 points:\n\n"
        f"{text}\n\n"
        "Summary:\n\n"
        "Plan of Action (5 points):\n"
    )
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=300,
        temperature=0.7
    )
    summary_and_plan = response.choices[0].message["content"].strip()
    return summary_and_plan

def send_email(summary_and_plan, sender_email, receiver_email, email_password):
    """Sends an email with the provided message."""
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = "Summary and Plan of Action"
    msg.attach(MIMEText(summary_and_plan, 'plain'))

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, email_password)
        server.sendmail(sender_email, receiver_email, msg.as_string())
        print('Email sent successfully!')
    except Exception as e:
        print(f'Error sending email: {e}')
    finally:
        server.quit()

def convert_video_to_text_and_summarize(bucket_name, object_name, access_key_id, secret_access_key, region_name, openai_api_key, sender_email, receiver_email, email_password):
    """Converts video from S3 to text, summarizes, and sends an email."""
    downloaded_video_path = "downloaded_video.mp4"
    if not download_file_from_s3(bucket_name, object_name, downloaded_video_path, access_key_id, secret_access_key, region_name):
        return

    # Extract audio and transcribe
    temporary_audio_file = "temp_audio.mp3"
    subprocess.run(["ffmpeg", "-i", downloaded_video_path, "-vn", temporary_audio_file])
    model = load_model("base")
    result = model.transcribe(temporary_audio_file)
    text = result["text"]

    # Clean up temporary files
    os.remove(temporary_audio_file)
    os.remove(downloaded_video_path)

    # Summarize and generate plan
    summary_and_plan = summarize_and_generate_plan(text, openai_api_key)

    # Send email notification
    send_email(summary_and_plan, sender_email, receiver_email, email_password)

# Example usage (replace with your actual credentials)
bucket_name = "meeting-summarizer-internship"
object_name = "m2.mp4"
access_key_id = "AKIAYAV34GOXGLQT2OVM"
secret_access_key = "Mq3cEsJMCnqfYZSe63zdXl8wca9Dzl1hUqvM9ZSW"
region_name = "ap-south-1"
openai_api_key = "sk-proj-2B9XaHHDeIAdXj0kj71iT3BlbkFJWq3QDjgQVNbHyjPmdlXH"
sender_email = "SENDER_MAIL"
receiver_email = "RECEIVER_MAIL"
email_password = "PASSWORD"

convert_video_to_text_and_summarize(bucket_name, object_name, access_key_id, secret_access_key, region_name, openai_api_key, sender_email, receiver_email, email_password)
